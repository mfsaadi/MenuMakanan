package com.example.hitungbbmperjalanan;

public class Kendaraan {
    String nama;
    double konsumsi;

    public Kendaraan(String nama, double konsumsi) {
        this.nama = nama;
        this.konsumsi = konsumsi;
    }

    @Override
    public String toString() {
        return nama + " ("+konsumsi+" Km/liter)";
    }
}
